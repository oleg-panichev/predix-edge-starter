
All mbsa application logs will be placed here.